package oauth;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.okta.jwt.AccessTokenVerifier;
import com.okta.jwt.Jwt;
import com.okta.jwt.JwtVerificationException;
import fish.payara.security.oauth2.api.OAuth2AccessToken;
import java.io.IOException;
import java.io.PrintWriter;
import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import fish.payara.security.openid.api.OpenIdContext;
import javax.json.JsonObject;


/**
 *
 * @author root
 */
//@Dependent
public class ProtectedServlet extends HttpServlet {
@Inject OAuth2AccessToken token;
    

@Inject OpenIdContext context;
    

private AccessTokenVerifier jwtVerifier;
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ProtectedServlet</title>");            
            out.println("</head>");
            out.println("<body>");
        //    context.
      
        String token = context.getAccessToken().toString();
        out.println("\nAccess Token : "+token);
        //Here's tOpenIdContextImpl.getSubjecthe identity token
        out.println("\nIdentity Token : "+context.getIdentityToken());
        //Here's the user claims
        JsonObject json =context.getClaimsJson(); 
        String groups = context.getCallerGroups();
      out.println("\nClaims :"+json.toString());
      out.println("\ngroups  :"+ groups);
      out.println("\nEmail = :"+json.getString("email"));
        //  response.setHeader("Authorization","Bearer "+ context.getAccessToken() );
        
       try {
                Jwt jwt = jwtVerifier.decode(token);
                
                out.println("Hello, " + jwt.getClaims().get("email"));
            } catch (JwtVerificationException e) {
                e.printStackTrace();
              //  response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Access denied.");
               
            }
        
       
            out.println("<h1>Open Id Servlet ProtectedServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
