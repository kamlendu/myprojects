/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package keytest;

import java.io.FileOutputStream;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import sutil.PrivateKeyReader;
import sutil.PublicKeyReader;

/**
 *
 * @author root
 */
public class KeyTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       
        PublicKeyReader pubreader  = new PublicKeyReader("/root/Desktop/microservices/serverpublickey.pem");
        PrivateKeyReader prreader  = new PrivateKeyReader("/root/Desktop/microservices/serverprivatekey.pem");
               
//  PublicKeyReader preader  = new PublicKeyReader("serverpublickey.pem");
        
        PublicKey pbkey = pubreader.getPublicKeyforPEMFile();
        System.out.print(pbkey.getEncoded());
        PrivateKey prkey = prreader.getPrivateKeyforPEMFile();       
        System.out.print(prkey.getEncoded());
    }
 
    void keyGenerate()
    {
         try{
        KeyPairGenerator keyGenerator = KeyPairGenerator.getInstance("RSA");
		keyGenerator.initialize(1024);

		KeyPair kp = keyGenerator.genKeyPair();
                System.out.println("Private :"+ kp.getPrivate());
		PublicKey publicKey = (PublicKey) kp.getPublic();
		PrivateKey privateKey = (PrivateKey) kp.getPrivate();
        
                byte[] pbkey = publicKey.getEncoded();
                FileOutputStream keyfos = new FileOutputStream("pbencode");
                keyfos.write(pbkey);
                keyfos.close();
                 byte[] prkey = privateKey.getEncoded();
                FileOutputStream keyfos1 = new FileOutputStream("prencode");
                keyfos1.write(prkey);
                keyfos1.close();
               
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    private static String convertToPublicKey(String key){
		StringBuilder result = new StringBuilder();
		result.append("-----BEGIN PUBLIC KEY-----\n");
		result.append(key);
		result.append("\n-----END PUBLIC KEY-----");
		return result.toString();
	}
    private static String convertToPrivateKey(String key){
		StringBuilder result = new StringBuilder();
		result.append("-----BEGIN PRIVATE KEY-----\n");
		result.append(key);
		result.append("\n-----END PRIVATE KEY-----");
		return result.toString();
	}
    
}
