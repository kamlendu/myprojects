/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sutil;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.spec.PKCS8EncodedKeySpec;
import sun.misc.BASE64Decoder;

/**
 *
 * @author root
 */
public class PrivateKeyReader {
    private PrivateKey privateKey;
    private String fileName; // path and File Name of .pem file eg. "/WEB-INF/private.pem"

    
    
    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public PrivateKeyReader() {
    }

    public PrivateKeyReader(String fileName) {
        this.fileName = fileName;
    }
    
    
    
   public PrivateKey getPrivateKeyforPEMFile()
    {
        try{
            java.security.Security.addProvider(
         new org.bouncycastle.jce.provider.BouncyCastleProvider()
);
        File f = new File(fileName);
      FileInputStream inputStream = new FileInputStream(f);
   //   InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream(fileName);
    //  FileInputStream fis = new FileInputStream();
      
      DataInputStream dis = new DataInputStream(inputStream);
      byte[] keyBytes = new byte[(int) f.length()];
      dis.readFully(keyBytes);
      dis.close();

      String temp = new String(keyBytes);
      String privateKeyPEM = temp.replace("-----BEGIN RSA PRIVATE KEY-----\n", "");
      privateKeyPEM = privateKeyPEM.replace("-----END RSA PRIVATE KEY-----", "");
 System.out.println("\nPrivate key = "+privateKeyPEM);
     
        BASE64Decoder b64 = new BASE64Decoder();
      byte[] decoded = b64.decodeBuffer(privateKeyPEM);
      FileOutputStream keyfos = new FileOutputStream("privateencoded");
                keyfos.write(decoded);
                keyfos.close();
      
      System.out.println("\nPrivate Encoded = "+decoded);
      PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(decoded);
      KeyFactory kf = KeyFactory.getInstance("RSA");
      return kf.generatePrivate(spec);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return privateKey;
    }
    
}
