/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sutil;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import sun.misc.BASE64Decoder;

/**
 *
 * @author root
 */
public class PublicKeyReader {
    private PublicKey publicKey;
    private String fileName; // path and File Name of .pem file eg. "/WEB-INF/private.pem"

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public PublicKeyReader() {
    }

    public PublicKeyReader(String fileName) {
        this.fileName = fileName;
    }
    
    
    
   public PublicKey getPublicKeyforPEMFile()
    {
        try{
        File f = new File(fileName);
      FileInputStream inputStream = new FileInputStream(f);
   //   InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream(fileName);
    //  FileInputStream fis = new FileInputStream();
      
      DataInputStream dis = new DataInputStream(inputStream);
      byte[] keyBytes = new byte[(int) f.length()];
      dis.readFully(keyBytes);
      dis.close();

      String temp = new String(keyBytes);
      String publicKeyPEM = temp.replace("-----BEGIN PUBLIC KEY-----\n", "");
      publicKeyPEM = publicKeyPEM.replace("-----END PUBLIC KEY-----", "");


      BASE64Decoder b64 = new BASE64Decoder();
      byte[] decoded = b64.decodeBuffer(publicKeyPEM);
      FileOutputStream keyfos = new FileOutputStream("publicencoded");
                keyfos.write(decoded);
                keyfos.close();
      
      System.out.println("Encoded = "+decoded);
      
      X509EncodedKeySpec spec = new X509EncodedKeySpec(decoded);
      KeyFactory kf = KeyFactory.getInstance("RSA");
      publicKey= kf.generatePublic(spec);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return publicKey;
    }
    
}
